var searchData=
[
  ['name',['name',['../class_g_s_resource.html#a1fa73ffe478c5debaa2cbf3f56e8a47f',1,'GSResource']]],
  ['newdocument_3a',['newDocument:',['../class_g_s_document_tree_controller.html#a51031c173a796378b921ba4b25c331ab',1,'GSDocumentTreeController']]],
  ['nodesbyuid',['nodesByUid',['../class_g_s_document_tree_controller.html#a38d2252867430d7966a35be7923c8a3f',1,'GSDocumentTreeController']]],
  ['notifydelegates_3a',['notifyDelegates:',['../class_g_s_o_item_view.html#a4dd896bca8379335d077c88ba3bb262b',1,'GSOItemView']]]
];
