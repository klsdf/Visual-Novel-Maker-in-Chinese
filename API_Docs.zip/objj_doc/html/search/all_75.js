var searchData=
[
  ['uid',['uid',['../class_g_s_document.html#a899362f9e712526aaca46c5a81493651',1,'GSDocument']]],
  ['unmarkitemastemporary_3a',['unmarkItemAsTemporary:',['../class_g_s_document.html#a56e220ad4aef121baebdf11ffe84fd73',1,'GSDocument']]],
  ['unusedrecordidforcategory_3a',['unusedRecordIdForCategory:',['../class_g_s_database.html#a291a7eaf33c68a49a61977afaeb87143',1,'GSDatabase']]],
  ['update',['update',['../class_g_s_o_data_source.html#a9ae41d5660eca72e0ea6950dc18a66f1',1,'GSODataSource::update()'],['../class_g_s_o_item_view.html#a4259b50a8cd6e059ecd312fdaa2c2fd8',1,'GSOItemView::update()'],['../class_g_s_o_tree_data_source.html#a8af25c2d6c33389f6ccbd952bdbc1f9e',1,'GSOTreeDataSource::update()']]],
  ['updatefolders',['updateFolders',['../class_g_s_resource_manager.html#a4ab7203101e1a6682089a4161c7adc4b',1,'GSResourceManager']]],
  ['updatesortorder_3astartindex_3a',['updateSortOrder:startIndex:',['../class_g_s_database.html#a5593460f98620d0b5f63359a5cd3272a',1,'GSDatabase']]]
];
